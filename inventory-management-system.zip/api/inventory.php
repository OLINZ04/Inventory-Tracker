<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

require_once '../config/database.php';

$database = new Database();
$db = $database->getConnection();

$method = $_SERVER['REQUEST_METHOD'];
$request = isset($_GET['action']) ? $_GET['action'] : '';

switch($method) {
    case 'GET':
        if($request === 'items') {
            getItems($db);
        } elseif($request === 'item' && isset($_GET['id'])) {
            getItem($db, $_GET['id']);
        } elseif($request === 'transactions' && isset($_GET['item_id'])) {
            getTransactions($db, $_GET['item_id']);
        }
        break;
    
    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        if($request === 'add_item') {
            addItem($db, $data);
        } elseif($request === 'pull_in') {
            pullInStock($db, $data);
        } elseif($request === 'pull_out') {
            pullOutStock($db, $data);
        }
        break;
    
    case 'PUT':
        $data = json_decode(file_get_contents("php://input"));
        if($request === 'update_item') {
            updateItem($db, $data);
        }
        break;
    
    case 'DELETE':
        if($request === 'delete_item' && isset($_GET['id'])) {
            deleteItem($db, $_GET['id']);
        }
        break;
}

function getItems($db) {
    $query = "SELECT * FROM items ORDER BY created_at DESC";
    $stmt = $db->prepare($query);
    $stmt->execute();
    
    $items = array();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $items[] = $row;
    }
    
    echo json_encode($items);
}

function getItem($db, $id) {
    $query = "SELECT * FROM items WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    $item = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode($item);
}

function addItem($db, $data) {
    $query = "INSERT INTO items (item_name, category, boxes, pieces, total_pieces, pieces_per_box) 
              VALUES (:item_name, :category, 0, 0, 0, :pieces_per_box)";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':item_name', $data->item_name);
    $stmt->bindParam(':category', $data->category);
    $pieces_per_box = isset($data->pieces_per_box) ? $data->pieces_per_box : 24;
    $stmt->bindParam(':pieces_per_box', $pieces_per_box);
    
    if($stmt->execute()) {
        echo json_encode(array("message" => "Item added successfully", "id" => $db->lastInsertId()));
    } else {
        echo json_encode(array("message" => "Failed to add item"));
    }
}

function updateItem($db, $data) {
    $query = "UPDATE items SET item_name = :item_name, category = :category 
              WHERE id = :id";
    
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $data->id);
    $stmt->bindParam(':item_name', $data->item_name);
    $stmt->bindParam(':category', $data->category);
    
    if($stmt->execute()) {
        echo json_encode(array("message" => "Item updated successfully"));
    } else {
        echo json_encode(array("message" => "Failed to update item"));
    }
}

function deleteItem($db, $id) {
    $query = "DELETE FROM items WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $id);
    
    if($stmt->execute()) {
        echo json_encode(array("message" => "Item deleted successfully"));
    } else {
        echo json_encode(array("message" => "Failed to delete item"));
    }
}

function pullInStock($db, $data) {
    try {
        $db->beginTransaction();
        
        // Get current item data
        $query = "SELECT * FROM items WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->item_id);
        $stmt->execute();
        $item = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $previous_stock = $item['boxes'] . " Boxes & " . $item['pieces'] . " Pcs";
        
        // Calculate new stock
        $pieces_to_add = 0;
        if($data->unit_type === 'boxes') {
            $pieces_to_add = $data->quantity * $item['pieces_per_box'];
            $new_boxes = $item['boxes'] + $data->quantity;
            $new_pieces = $item['pieces'];
        } else {
            $pieces_to_add = $data->quantity;
            $new_boxes = $item['boxes'];
            $new_pieces = $item['pieces'] + $data->quantity;
            
            // Convert pieces to boxes if necessary
            while($new_pieces >= $item['pieces_per_box']) {
                $new_pieces -= $item['pieces_per_box'];
                $new_boxes++;
            }
        }
        
        $new_total = $item['total_pieces'] + $pieces_to_add;
        $new_stock = $new_boxes . " Boxes & " . $new_pieces . " Pcs";
        
        // Update item
        $query = "UPDATE items SET boxes = :boxes, pieces = :pieces, total_pieces = :total_pieces 
                  WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':boxes', $new_boxes);
        $stmt->bindParam(':pieces', $new_pieces);
        $stmt->bindParam(':total_pieces', $new_total);
        $stmt->bindParam(':id', $data->item_id);
        $stmt->execute();
        
        // Record transaction
        $query = "INSERT INTO transactions (item_id, transaction_type, quantity, unit_type, pieces_affected, previous_stock, new_stock) 
                  VALUES (:item_id, 'pull_in', :quantity, :unit_type, :pieces_affected, :previous_stock, :new_stock)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':item_id', $data->item_id);
        $stmt->bindParam(':quantity', $data->quantity);
        $stmt->bindParam(':unit_type', $data->unit_type);
        $stmt->bindParam(':pieces_affected', $pieces_to_add);
        $stmt->bindParam(':previous_stock', $previous_stock);
        $stmt->bindParam(':new_stock', $new_stock);
        $stmt->execute();
        
        $db->commit();
        echo json_encode(array("message" => "Stock pulled in successfully", "new_stock" => $new_stock));
    } catch(Exception $e) {
        $db->rollBack();
        echo json_encode(array("message" => "Failed to pull in stock: " . $e->getMessage()));
    }
}

function pullOutStock($db, $data) {
    try {
        $db->beginTransaction();
        
        // Get current item data
        $query = "SELECT * FROM items WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':id', $data->item_id);
        $stmt->execute();
        $item = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $previous_stock = $item['boxes'] . " Boxes & " . $item['pieces'] . " Pcs";
        
        // Calculate new stock
        $pieces_to_remove = 0;
        if($data->unit_type === 'boxes') {
            $pieces_to_remove = $data->quantity * $item['pieces_per_box'];
            $new_boxes = $item['boxes'] - $data->quantity;
            $new_pieces = $item['pieces'];
        } else {
            $pieces_to_remove = $data->quantity;
            $new_boxes = $item['boxes'];
            $new_pieces = $item['pieces'] - $data->quantity;
            
            // Borrow from boxes if necessary
            while($new_pieces < 0) {
                if($new_boxes > 0) {
                    $new_pieces += $item['pieces_per_box'];
                    $new_boxes--;
                } else {
                    throw new Exception("Insufficient stock");
                }
            }
        }
        
        if($new_boxes < 0) {
            throw new Exception("Insufficient stock");
        }
        
        $new_total = $item['total_pieces'] - $pieces_to_remove;
        if($new_total < 0) {
            throw new Exception("Insufficient stock");
        }
        
        $new_stock = $new_boxes . " Boxes & " . $new_pieces . " Pcs";
        
        // Update item
        $query = "UPDATE items SET boxes = :boxes, pieces = :pieces, total_pieces = :total_pieces 
                  WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':boxes', $new_boxes);
        $stmt->bindParam(':pieces', $new_pieces);
        $stmt->bindParam(':total_pieces', $new_total);
        $stmt->bindParam(':id', $data->item_id);
        $stmt->execute();
        
        // Record transaction
        $query = "INSERT INTO transactions (item_id, transaction_type, quantity, unit_type, pieces_affected, previous_stock, new_stock) 
                  VALUES (:item_id, 'pull_out', :quantity, :unit_type, :pieces_affected, :previous_stock, :new_stock)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':item_id', $data->item_id);
        $stmt->bindParam(':quantity', $data->quantity);
        $stmt->bindParam(':unit_type', $data->unit_type);
        $stmt->bindParam(':pieces_affected', $pieces_to_remove);
        $stmt->bindParam(':previous_stock', $previous_stock);
        $stmt->bindParam(':new_stock', $new_stock);
        $stmt->execute();
        
        $db->commit();
        echo json_encode(array("message" => "Stock pulled out successfully", "new_stock" => $new_stock));
    } catch(Exception $e) {
        $db->rollBack();
        echo json_encode(array("message" => "Failed to pull out stock: " . $e->getMessage()));
    }
}

function getTransactions($db, $item_id) {
    $query = "SELECT * FROM transactions WHERE item_id = :item_id ORDER BY transaction_date DESC";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':item_id', $item_id);
    $stmt->execute();
    
    $transactions = array();
    while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $transactions[] = $row;
    }
    
    echo json_encode($transactions);
}
?>
