// API Configuration
const API_BASE_URL = 'api/inventory.php';

// Global state
let currentItem = null;
let allItems = [];

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    loadInventory();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Search functionality
    document.getElementById('searchInput').addEventListener('input', function(e) {
        filterInventory(e.target.value);
    });

    // Pull in/out quantity change listeners
    const pullInQuantity = document.getElementById('pullInQuantity');
    const pullInUnit = document.getElementById('pullInUnit');
    const pullOutQuantity = document.getElementById('pullOutQuantity');
    const pullOutUnit = document.getElementById('pullOutUnit');

    if (pullInQuantity && pullInUnit) {
        pullInQuantity.addEventListener('input', updatePullInPreview);
        pullInUnit.addEventListener('change', updatePullInPreview);
    }

    if (pullOutQuantity && pullOutUnit) {
        pullOutQuantity.addEventListener('input', updatePullOutPreview);
        pullOutUnit.addEventListener('change', updatePullOutPreview);
    }

    // Close modals on background click
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                modal.classList.remove('active');
            }
        });
    });
}

// Load inventory data
async function loadInventory() {
    try {
        const response = await fetch(`${API_BASE_URL}?action=items`);
        const items = await response.json();
        allItems = items;
        renderInventory(items);
    } catch (error) {
        console.error('Error loading inventory:', error);
        showToast('Failed to load inventory', 'error');
    }
}

// Render inventory table
function renderInventory(items) {
    const tbody = document.getElementById('inventoryTableBody');
    
    if (items.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="empty-state">
                    <h3>No items found</h3>
                    <p>Add your first item to get started</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = items.map(item => {
        const isLowStock = parseInt(item.boxes) === 0 && parseInt(item.pieces) < 30;
        const stockClass = isLowStock ? 'low-stock' : '';
        const lowStockIndicator = isLowStock ? '<span class="low-stock-indicator"></span>' : '';

        return `
            <tr>
                <td>
                    <div class="item-name">${escapeHtml(item.item_name)}</div>
                </td>
                <td>
                    <span class="category-badge">${escapeHtml(item.category)}</span>
                </td>
                <td>
                    <div class="stock-info">
                        <span class="stock-main ${stockClass}">
                            ${item.boxes} Boxes & ${item.pieces} Pcs${lowStockIndicator}
                        </span>
                        <span class="stock-total">${item.total_pieces} total pcs</span>
                    </div>
                </td>
                <td>
                    <div class="actions-group">
                        <button class="btn btn-success" onclick="openPullInModal(${item.id})">Pull In</button>
                        <button class="btn btn-danger" onclick="openPullOutModal(${item.id})">Pull Out</button>
                        <button class="btn-icon" onclick="openEditItemModal(${item.id})" title="Edit">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M14.166 2.5C14.3849 2.28113 14.6447 2.10752 14.9307 1.98906C15.2167 1.87061 15.5232 1.80969 15.8327 1.80969C16.1422 1.80969 16.4487 1.87061 16.7347 1.98906C17.0206 2.10752 17.2805 2.28113 17.4993 2.5C17.7182 2.71887 17.8918 2.97871 18.0103 3.26468C18.1287 3.55064 18.1897 3.85714 18.1897 4.16667C18.1897 4.47619 18.1287 4.78269 18.0103 5.06866C17.8918 5.35462 17.7182 5.61446 17.4993 5.83333L6.24935 17.0833L1.66602 18.3333L2.91602 13.75L14.166 2.5Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                        <button class="btn-icon" onclick="deleteItem(${item.id})" title="Delete">
                            <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M2.5 5H4.16667H17.5" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                                <path d="M6.66602 5.00016V3.3335C6.66602 2.89147 6.84161 2.46754 7.15417 2.15499C7.46673 1.84243 7.89065 1.66683 8.33268 1.66683H11.666C12.108 1.66683 12.532 1.84243 12.8445 2.15499C13.1571 2.46754 13.3327 2.89147 13.3327 3.3335V5.00016M15.8327 5.00016V16.6668C15.8327 17.1089 15.6571 17.5328 15.3445 17.8453C15.032 18.1579 14.608 18.3335 14.166 18.3335H5.83268C5.39065 18.3335 4.96673 18.1579 4.65417 17.8453C4.34161 17.5328 4.16602 17.1089 4.16602 16.6668V5.00016H15.8327Z" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                            </svg>
                        </button>
                    </div>
                </td>
            </tr>
        `;
    }).join('');
}

// Filter inventory
function filterInventory(searchTerm) {
    const filtered = allItems.filter(item => {
        const searchLower = searchTerm.toLowerCase();
        return item.item_name.toLowerCase().includes(searchLower) ||
               item.category.toLowerCase().includes(searchLower);
    });
    renderInventory(filtered);
}

// Open Pull In Modal
async function openPullInModal(itemId) {
    try {
        const response = await fetch(`${API_BASE_URL}?action=item&id=${itemId}`);
        currentItem = await response.json();
        
        document.getElementById('pullInItemName').textContent = currentItem.item_name;
        document.getElementById('pullInCurrentStock').textContent = 
            `${currentItem.boxes} Boxes & ${currentItem.pieces} Pcs`;
        document.getElementById('pullInQuantity').value = 1;
        document.getElementById('pullInUnit').value = 'boxes';
        
        updatePullInPreview();
        document.getElementById('pullInModal').classList.add('active');
    } catch (error) {
        console.error('Error opening pull in modal:', error);
        showToast('Failed to load item details', 'error');
    }
}

// Update pull in preview
function updatePullInPreview() {
    if (!currentItem) return;
    
    const quantity = parseInt(document.getElementById('pullInQuantity').value) || 0;
    const unit = document.getElementById('pullInUnit').value;
    
    let totalPieces = 0;
    if (unit === 'boxes') {
        totalPieces = quantity * parseInt(currentItem.pieces_per_box);
    } else {
        totalPieces = quantity;
    }
    
    document.getElementById('pullInPreview').textContent = `${totalPieces} total pieces`;
}

// Confirm pull in
async function confirmPullIn() {
    const quantity = parseInt(document.getElementById('pullInQuantity').value);
    const unitType = document.getElementById('pullInUnit').value;
    
    if (!quantity || quantity <= 0) {
        showToast('Please enter a valid quantity', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}?action=pull_in`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                item_id: currentItem.id,
                quantity: quantity,
                unit_type: unitType
            })
        });
        
        const result = await response.json();
        
        if (result.message.includes('success')) {
            showToast('Stock pulled in successfully', 'success');
            closePullInModal();
            loadInventory();
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error('Error pulling in stock:', error);
        showToast('Failed to pull in stock', 'error');
    }
}

// Close pull in modal
function closePullInModal() {
    document.getElementById('pullInModal').classList.remove('active');
    currentItem = null;
}

// Open Pull Out Modal
async function openPullOutModal(itemId) {
    try {
        const response = await fetch(`${API_BASE_URL}?action=item&id=${itemId}`);
        currentItem = await response.json();
        
        document.getElementById('pullOutItemName').textContent = currentItem.item_name;
        document.getElementById('pullOutCurrentStock').textContent = 
            `${currentItem.boxes} Boxes & ${currentItem.pieces} Pcs`;
        document.getElementById('pullOutQuantity').value = 1;
        document.getElementById('pullOutUnit').value = 'boxes';
        
        updatePullOutPreview();
        document.getElementById('pullOutModal').classList.add('active');
    } catch (error) {
        console.error('Error opening pull out modal:', error);
        showToast('Failed to load item details', 'error');
    }
}

// Update pull out preview
function updatePullOutPreview() {
    if (!currentItem) return;
    
    const quantity = parseInt(document.getElementById('pullOutQuantity').value) || 0;
    const unit = document.getElementById('pullOutUnit').value;
    
    let totalPieces = 0;
    if (unit === 'boxes') {
        totalPieces = quantity * parseInt(currentItem.pieces_per_box);
    } else {
        totalPieces = quantity;
    }
    
    document.getElementById('pullOutPreview').textContent = `${totalPieces} total pieces`;
}

// Confirm pull out
async function confirmPullOut() {
    const quantity = parseInt(document.getElementById('pullOutQuantity').value);
    const unitType = document.getElementById('pullOutUnit').value;
    
    if (!quantity || quantity <= 0) {
        showToast('Please enter a valid quantity', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}?action=pull_out`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                item_id: currentItem.id,
                quantity: quantity,
                unit_type: unitType
            })
        });
        
        const result = await response.json();
        
        if (result.message.includes('success')) {
            showToast('Stock pulled out successfully', 'success');
            closePullOutModal();
            loadInventory();
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error('Error pulling out stock:', error);
        showToast('Failed to pull out stock', 'error');
    }
}

// Close pull out modal
function closePullOutModal() {
    document.getElementById('pullOutModal').classList.remove('active');
    currentItem = null;
}

// Switch between pull in and pull out
function switchToPullOut() {
    closePullInModal();
    openPullOutModal(currentItem.id);
}

function switchToPullIn() {
    closePullOutModal();
    openPullInModal(currentItem.id);
}

function switchTab(tab) {
    // This function is for visual feedback only
}

// Open Add Item Modal
function openAddItemModal() {
    document.getElementById('addItemName').value = '';
    document.getElementById('addItemCategory').value = 'Hardware';
    document.getElementById('addItemModal').classList.add('active');
}

// Close Add Item Modal
function closeAddItemModal() {
    document.getElementById('addItemModal').classList.remove('active');
}

// Confirm add item
async function confirmAddItem() {
    const itemName = document.getElementById('addItemName').value.trim();
    const category = document.getElementById('addItemCategory').value;
    
    if (!itemName) {
        showToast('Please enter an item name', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}?action=add_item`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                item_name: itemName,
                category: category
            })
        });
        
        const result = await response.json();
        
        if (result.message.includes('success')) {
            showToast('Item added successfully', 'success');
            closeAddItemModal();
            loadInventory();
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error('Error adding item:', error);
        showToast('Failed to add item', 'error');
    }
}

// Open Edit Item Modal
async function openEditItemModal(itemId) {
    try {
        const response = await fetch(`${API_BASE_URL}?action=item&id=${itemId}`);
        currentItem = await response.json();
        
        document.getElementById('editItemName').value = currentItem.item_name;
        document.getElementById('editItemCategory').value = currentItem.category;
        
        document.getElementById('editItemModal').classList.add('active');
    } catch (error) {
        console.error('Error opening edit modal:', error);
        showToast('Failed to load item details', 'error');
    }
}

// Close Edit Item Modal
function closeEditItemModal() {
    document.getElementById('editItemModal').classList.remove('active');
    currentItem = null;
}

// Confirm edit item
async function confirmEditItem() {
    const itemName = document.getElementById('editItemName').value.trim();
    const category = document.getElementById('editItemCategory').value;
    
    if (!itemName) {
        showToast('Please enter an item name', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}?action=update_item`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                id: currentItem.id,
                item_name: itemName,
                category: category
            })
        });
        
        const result = await response.json();
        
        if (result.message.includes('success')) {
            showToast('Item updated successfully', 'success');
            closeEditItemModal();
            loadInventory();
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error('Error updating item:', error);
        showToast('Failed to update item', 'error');
    }
}

// Delete item
async function deleteItem(itemId) {
    if (!confirm('Are you sure you want to delete this item? This action cannot be undone.')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}?action=delete_item&id=${itemId}`, {
            method: 'DELETE'
        });
        
        const result = await response.json();
        
        if (result.message.includes('success')) {
            showToast('Item deleted successfully', 'success');
            loadInventory();
        } else {
            showToast(result.message, 'error');
        }
    } catch (error) {
        console.error('Error deleting item:', error);
        showToast('Failed to delete item', 'error');
    }
}

// Show toast notification
function showToast(message, type = 'success') {
    // Create toast element if it doesn't exist
    let toast = document.getElementById('toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'toast';
        toast.className = 'toast';
        document.body.appendChild(toast);
    }
    
    toast.textContent = message;
    toast.className = `toast ${type} show`;
    
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

// Utility function to escape HTML
function escapeHtml(text) {
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.replace(/[&<>"']/g, m => map[m]);
}
